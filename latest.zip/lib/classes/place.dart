abstract class Place {
  String get title;
}
