class level: tolist and from list
catalogue level: retrieve, add, remove
remove duplicates