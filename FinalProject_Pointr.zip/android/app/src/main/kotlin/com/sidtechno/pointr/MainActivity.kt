package com.example.pointr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
